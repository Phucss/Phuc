import React from 'react'
import './navbar.css'
export default class Navbar extends React.Component {
    render() {
      return (
        <section class="hero has-background-black">

        <div class="navbar">
          <div class="column center is-2">
            <img src="Logo VCS.png" sizes="auto"/>
          </div>
            <div className="column center is-4">
              <div className="search-box">
                <input className='search-text'type='text' placeholder='Type to Search'/>
                
                <a className='search-btn' href='#'>
                <i class="fas fa-search"></i>
                </a>
              </div>
            </div>
            <div class="column center">
              Home
          </div>
            <div class="column center">
              Ads
          </div>
            <div class="column center">
              Projects
          </div>

          </div>
  
  
        </section>
      )
    }
}