import React from 'react'
import './footer.css'

export default class Footer extends React.Component {
    render() {
        return (
           

                <footer className='footer has-background-black'>

                    <div className='info'>
                        s3740915
                    </div>

                </footer>

             

            
        )
    }
}

