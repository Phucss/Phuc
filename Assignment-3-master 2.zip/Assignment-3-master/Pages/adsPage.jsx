import React from 'react'
export default class AdsPage extends React.Component{

    render(){
        return(
            <div>

                
                

            </div>
        )
    }
}