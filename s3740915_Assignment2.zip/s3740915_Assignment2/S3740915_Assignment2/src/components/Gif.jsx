import React, { Component } from 'react'
import './gif.css'

export default class Home extends Component {
    render() {
        return (
            <div id="home">
                <div className="landing-text">
                    <h1 >Welcome to Online Market</h1>
                    <h3>Click on the buttons to start explore</h3> <br />
                    <div className="container">
                        <div className="row">
                            <div className="col-sm-6" align="center">
                                <button className="explore"><a className="a1" href="/productslist">Explore Our Products Now !!!</a></button>
                            	
                            </div>
                            <div className="col-sm-6" align="center">
                            <button className="explore"><a className="a1" href="/producttypeslist">Want To See All The ProductType ?</a></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
