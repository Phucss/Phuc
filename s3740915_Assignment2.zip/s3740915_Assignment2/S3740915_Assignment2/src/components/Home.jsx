import React, { Component } from 'react'


import Navbar from './Navbar.jsx';
import Gif from './Gif.jsx';

export default class Home extends Component {
	render() {
		return (
			<div>
				<Navbar></Navbar>
				<Gif></Gif>	
				
			</div>

		)
	}
}
