import React, { Component } from 'react'

export default class ProductForm extends Component {
	constructor(props) {
		super(props);
		this.state = {
			id: '',
			name: '',
			price: '',
			description: '',
			brand: '',
			producer: '',
			imageUrl: '',
			productType: ''
		}
	}

	componentWillReceiveProps(props) {
		this.setState(props.editProduct)
	}

	handleChange(e) {
		let change = {};
		change[e.target.name] = e.target.value;
		this.setState(change);
	}

	handleSubmit() {
		if (this.state._id === undefined || this.state._id === null) {
			console.log('Add case called')
			this.props.addProduct(this.state);
			this.clearForm()
			this.props.closeForm()
		}
		else {
			console.log('Edit case called')
			this.props.updateProduct(this.state)
			this.clearForm()
			this.props.closeForm()
		}
	}
	clearForm() {
		this.setState({
			id: '',
			name: '',
			price: '',
			description: '',
			brand: '',
			producer: '',
			imageUrl: '',
			productType: '',
		})
	}





	render() {
		return (
			<div>
				<div className="container-fluid">
					<div className="row">
						
						<div className="col-sm-12">
							<div className='card'>
								<div className='card-header text-center bg-standard text-black'>
									{!this.state._id ? 'Product Information' : 'Edit Form'}
									
									
								</div>
								<div className='card-body'>
									<form onSubmit="alert('Submission Successful!')">
										<div className='form-group'>
											<div className='form-row'>
												<label>ID</label>
												<input type='text' name='id' className='form-control' placeholder='Product ID'
													value={this.state.id} onChange={this.handleChange.bind(this)} autoFocus />
													<legend></legend>
												<label>Product Name</label>
												<input type='text' name='name' className='form-control' placeholder='Product Name'
													value={this.state.name} onChange={this.handleChange.bind(this)}  />
											</div>
										</div>

										<div className='form-group'>
											<label>Price</label>
											<input type='text' name='price' className='form-control' placeholder='Product Price'
												value={this.state.price} onChange={this.handleChange.bind(this)}  />
										</div>

										<div className='form-group'>
											<label>Description:</label>
											<input className='form-control' name='description' placeholder="Write something about Product"
												value={this.state.description} onChange={this.handleChange.bind(this)} 
											/>
										</div>

										<div className='form-group'>
											<div className='form-row'>
												<label>Brand</label>
												<input type='text' name='brand' className='form-control' placeholder='Product Brand'
													value={this.state.brand} onChange={this.handleChange.bind(this)}  />

												<label>Producer</label>
												<input type='text' name='producer' className='form-control' placeholder='Product Producer'
													value={this.state.producer} onChange={this.handleChange.bind(this)}  />
											</div>
										</div>

										<div className='form-group'>
											<label>Image URL</label>
											<input type='text' name='imageUrl' className='form-control' placeholder='Image URL'
												value={this.state.imageUrl} onChange={this.handleChange.bind(this)} validations />
										</div>

										<div className="form-group">
											<label>Select Product Type</label>
											<select style={{ height: '34px' }} className="form-control" name="productType" onChange={this.handleChange.bind(this)}>
												
												{this.props.productTypes.map((type, index) =>
													<option key={index} value={type.id} >{type.name}</option>
												)}
											</select>
										</div>
										<br />
										<button className='btn btn-standard inline mr-1'
											onClick={this.handleSubmit.bind(this)}
										>
											{!this.state._id ? 'Add' : 'Save'}
										</button>
									
									</form>
								</div>
							</div>
						</div>
					
					</div>
				</div>
			</div>
		)
	}
}
