import React, { Component } from 'react'
import ProductForm from './ProductForm.jsx'
import './viewByGrid.css'

export default class ViewByGrid extends Component {
    constructor(props) {
        super(props);
        this.state = {
            formVisibility: false,
            currentProducts: props.ads,
        }
    }

    componentWillReceiveProps(nextProps) {
        this.setState({ currentProducts: nextProps.ads })
    }

    handleFilterByCategory(id) {
        if (id !== 'all') {
            let sameType = this.props.products.filter((product) => product.productType === id);
            this.setState({ currentProducts: sameType });
        }
        else if (id === 'all') {
            this.setState({ currentProducts: this.props.products })
        }

    }

    handleFilterByPrice(filter) {
        if (filter === 'LO_TO_HI') {
            let lowToHigh = this.props.products.sort(function (a, b) {
                return parseFloat(a.price) - parseFloat(b.price);
            });
            this.setState({ currentProducts: lowToHigh })


        }
        else if (filter === 'HI_TO_LO') {
            let highToLow = this.props.products.sort(function (a, b) {
                return parseFloat(b.price) - parseFloat(a.price);
            });
            this.setState({ currentProducts: highToLow })

        }
        else if (filter === '0_500') {
            let firstCase = this.props.products.filter((product) => product.price <= 500)
            this.setState({ currentProducts: firstCase })
        }
        else if (filter === '500_2000') {
            let secondCase = this.props.products.filter((product) => product.price >= 500 && product.price <= 2000)
            this.setState({ currentProducts: secondCase })
        }
      
        else if (filter === 'ABOVE_2000') {
            let fourthCase = this.props.products.filter((product) => product.price >= 2000)
            this.setState({ currentProducts: fourthCase })
        }
        else if (filter === 'ABOVE_5000') {
            let fifthCase = this.props.products.filter((product) => product.price >= 5000)
            this.setState({ currentProducts: fifthCase })
        }
        else if (filter === 'ABOVE_10000') {
            let sixthCase = this.props.products.filter((product) => product.price >= 10000)
            this.setState({ currentProducts: sixthCase })
        }
        else if (filter === 'ALL') {
            this.setState({ currentProducts: this.props.products })
        }
    }

    displayForm() {
        this.setState({ formVisibility: !this.state.formVisibility })
    }

    closeForm() {
        this.setState({ formVisibility: false })
    }

    handleEdit(_id) {
        this.displayForm()
        this.props.getProduct(_id)
    }

    onFind(e) {
        var target = e.target
        var name = target.name
        var value = target.value
        this.setState({
            [name]: value
        })
        var loweredKeyWord = this.state.keyWord.toLowerCase()
        if (this.state.keyWord === '') {
            this.setState({ currentProducts: this.props.products })
        }
        this.setState({
            currentProducts: this.props.products.filter(product =>
                product.name.toLowerCase().indexOf(loweredKeyWord) !== -1

            )
        })
    }

    clearKey() {
        this.setState({
            currentProducts: this.props.products,
            keyWord: ''
        })
    }

    render() {
        var { formVisibility } = this.state
        var productForm = formVisibility ? <ProductForm
            addProduct={(product) => this.props.addProduct(product)}
            closeForm={this.closeForm.bind(this)}
            editProduct={this.props.editProduct}
            updateProduct={(product) => this.props.updateProduct(product)}

            productTypes={this.props.productTypes} /> : null
        return (
            <div>

                <br /><br /><br />
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-sm-3">
                        </div>
                        <div className="col-sm-3" align="center">
                        <div className='card filter-card'>
                            <div className='card-header bg-dark text-white'>
                                <h4 className='card-title'>Filter</h4>
                            </div>
                            <div className='card-body'>
                                                                
                                <div className='card-header'>
                                    <h5 className='card-title'>
                                        <a href='#byPrice'>
                                            <i className></i> Price
							            </a>
                                    </h5>
                                </div>
                                <div id='byPrice' className='card-collapse collapse in' >
                                    <ul className='list-group'>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('ALL')}>
                                                All
                                            </button>
                                        </li>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('LO_TO_HI')}>
                                                Low To High
                                            </button>
                                        </li>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('HI_TO_LO')}>
                                                High To Low
                                            </button>
                                        </li>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('0_500')}>
                                                $0 - $500
                                            </button>
                                        </li>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('500_2000')}>
                                                $500 - $2000
                                            </button>
                                        </li>
                                        
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('ABOVE_2000')}>
                                                Above $2000
                                            </button>
                                        </li>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('ABOVE_5000')}>
                                                Above $5000
                                            </button>
                                        </li>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('ABOVE_10000')}>
                                                Above $10000
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                           
                        </div>
                        <div className="col-sm-3" align="center">
                        <div className="form-group">
                                <label htmlFor=""><h3>Search:</h3></label>

                                
                                <input style={{ width: '300px' }} type="text" className="form-control" name="keyWord" value={this.state.keyWord} onChange={this.onFind.bind(this)} />
                                <br/>
                                <button className="btn btn-standard" onClick={this.displayForm.bind(this)} >Add Product</button>
                              
                            </div>
                        </div>
                        <div className="col-sm-3">
                        </div>
                    </div>
                </div>
                <br />

                <div className="contaier-fluid">
                    <div className="row">
                        <div className="col-sm-3"></div>
                        <div className="col-sm-6">
                            {productForm}
                        </div>
                        <div className="col-sm-3"></div>
                    </div>
                </div>

                <br />

                <div className="row">
   

                    <div className="col-sm-12">
                        <div className="row">
                            {this.state.currentProducts.map((product, index) =>
                                <div className="col-sm-4" key={index} align="center" id="card">
                                    <div className='card border-dark card-cascade h-100 '>

                                        <img className='img card-img-top img-responsive imd-fluid' src={product.imageUrl} alt={product.name} width="300" height="300" />

                                        <div className='card-body'>
                                            <h4 className='h5 card-title'>{product.name}</h4>
                                            <hr />
                                            <p className='p card-text'><b>Price:</b>${product.price}</p>
                                            <p className='p card-text'><b>Brand:</b> {product.brand}</p>
                                            <p className='p card-text'><b>Producer:</b> {product.producer}</p>
                                        </div>

                                        <div className="card-body">
                                            <button className="btn btn-standard"><a href={`${product._id}`}>View</a></button> &nbsp;&nbsp;
                                            <button className="btn btn-danger" onClick={() => this.props.deleteProduct(product._id)}>Delete</button>&nbsp;&nbsp;
                                            <button className="btn btn-standard" onClick={() => this.handleEdit(product._id)}>Edit</button>&nbsp;&nbsp;
                                        </div>

                                        

                                    </div>
                                    <br />
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </div>

        )
    }
}
