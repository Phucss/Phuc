import React, { Component } from 'react'

export default class ProductDetails extends Component {
    render() {
        return (
            <div>
                <div className="container">
                    <div className="row">
                        
                        <div className="col-sm-12" align="center">
                            <h1 className="h1" >Ads Details</h1>
                        </div>
                        
                    </div>
                </div>
                <br /><br />
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12" align="center">
                            <h3 className="h3">{this.props.product.name}</h3>
                           
                        </div>
                 
                    </div>
                </div>
                <br /><br />
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12">
                            
                            <br /><br />
                            <h4 className="h4">Price: {this.props.product.price}</h4>
                            <h4 className="h4">Title: {this.props.product.title}</h4>
                            <h4 className="h4">Contact Info:</h4>
                            <p className="p">{this.props.product.contactinfo}</p>
                            <p className="p">{this.props.product.contactinfo}</p>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
