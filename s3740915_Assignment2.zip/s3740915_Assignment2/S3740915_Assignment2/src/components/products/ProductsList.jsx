import React, { Component } from 'react'
import ViewByList from '../products/ViewByList.jsx'
import ViewByGrid from '../products/ViewByGrid.jsx'
import './productList.css'
import Navbar from '../Navbar.jsx';

import Gif from '../Gif.jsx';


export default class ProductsList extends Component {
	constructor(props) {
		super(props)
		this.state = {
			viewByList: false,
			viewByGrid: false
		}
	}
	onViewList() {
		this.setState({
			viewByList: !this.state.viewByList,
			viewByGrid: false
		})
	}

	onViewGrid() {
		this.setState({
			viewByGrid: !this.state.viewByGrid,
			viewByList: false
		})
	}

	render() {
		return (
			<div>
				<Navbar></Navbar>
				<div align="center">
				<br/>
					<h2>
					Here is our Ads 
					</h2>
					<br/>
					<h2>
					You can choose to view it by List Mode or view it by Grid Mode
					</h2>
				</div>
			
				<div className="container">
					<div className="row">
						<div className="col-sm-12" align="center">
							<button className="btn" onClick={this.onViewList.bind(this)} >View By List&nbsp;&nbsp;&nbsp;</button>
							&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<button className="btn" onClick={this.onViewGrid.bind(this)} >View By Grid&nbsp;&nbsp;&nbsp;</button>
						</div>
					</div>
				</div>
				{this.state.viewByList ? <ViewByList
					onViewList={() => this.onViewList.bind(this)}
					products={this.props.products}
					addProduct={(product) => this.props.addProduct(product)}
					deleteProduct={(_id) => this.props.deleteProduct(_id)}
					getProduct={(_id) => this.props.getProduct(_id)}
					editProduct={this.props.editProduct}
					updateProduct={(product) => this.props.updateProduct(product)}
					productTypes={this.props.productTypes} /> : null}

				{this.state.viewByGrid ? <ViewByGrid
					onViewGrid={this.onViewGrid}
					products={this.props.products}
					addProduct={(product) => this.props.addProduct(product)}
					deleteProduct={(_id) => this.props.deleteProduct(_id)}
					getProduct={(_id) => this.props.getProduct(_id)}
					editProduct={this.props.editProduct}
					updateProduct={(product) => this.props.updateProduct(product)}

					productTypes={this.props.productTypes} /> : null}
				<br />
				
			</div>
		)
	}
}
