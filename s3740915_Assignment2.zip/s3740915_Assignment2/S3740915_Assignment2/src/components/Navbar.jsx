import React, { Component } from 'react'
import './navbar.css'


export default class Navbar extends Component {
	render() {
		return (
			<div className="row " align="center" >

				<div className="col-md-3">
					<a className="a nav-link" href="/home"><h3> Home</h3>  </a>
				</div>

				<div className="col-md-3">
					<a className="a nav-link" href="/about"><h3> Info and Contact</h3> </a>
				</div>
				<div className="col-md-3">
					<a className="a nav-link" href="/productslist"><h3> Products</h3> </a>
				</div>
				<div className="col-md-3">
					<a className="a nav-link" href="/producttypeslist"><h3> Products Type</h3> </a>
				</div>

			</div>
		)
	}
}