import React, { Component } from 'react'
import Navbar from './Navbar.jsx';

import Gif from './Gif.jsx'

export default class About extends Component {
	render() {
		return (
			<div>

				<Navbar></Navbar>
				<br />
				<br />

				<div className="container">
					Online Market is an Online Website that allows you to buy many kinds of product 
					online. We provide many categories but espescially electrical devices. Select the 
					tab on the menu to explore more.
					<br/>
					Contact us:
					<br/>
					Email:S3740915@rmit.edu.vn
					<br/>
					Thank you.

					</div>
				
			</div>
		)
	}
}