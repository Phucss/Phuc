export function toggleForm() {
    return {
        type: 'TOGGLE_FORM'
    };
}

export function closeForm() {
    return {
        type: 'CLOSE_FORM'
    }
}

export function openEditForm(){
    return {
        type: 'EDIT_FORM'
    }
}