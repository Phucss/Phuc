const editProductType = (state = {id: '', name: ''}, action) => {
    switch(action.type){
        case 'EDIT_TYPE':
            return action.payload;
        default: 
            return state;
    }
};

export default editProductType;