import React, { Component } from 'react';
import { connect } from 'react-redux';

import Home from './src/components/Home.jsx';
import About from './src/components/About.jsx';
import ProductTypesList from './src/components/productTypes/ProductTypesList.jsx';
import ProductsList from './src/components/products/ProductsList.jsx';
import ProductDetails from './src/components/products/ProductDetails.jsx';
import { fetchProductTypes, addProductType, deleteProductType, updateProductType, getProductType } from './src/actions/typeActions.jsx';
import { fetchProducts, addProduct, deleteProduct, getProduct, updateProduct } from './src/actions/productActions.jsx';

import './src/components/index.css'


class App extends React.Component {
    componentDidMount() {
        this.props.fetchProducts()
        this.props.fetchProductTypes()
    }


    render() {

        let path = window.location.pathname;
        let productPageURL = this.props.products.filter((p) => path.includes(p._id))
        let pageURL;
        for (let i = 0; i < productPageURL.length; i++) {
            if (productPageURL[i]._id !== '') {
                productPageURL = productPageURL[i];
                pageURL = productPageURL._id
                break;
            }
            else pageURL = null;
        }
        return (
            <div>
                {
                    path.includes('/home') ?
                        <Home />
                        : path.includes('productslist') ?
                            <ProductsList
                                products={this.props.products}
                                addProduct={(product) => this.props.addProduct(product)}
                                deleteProduct={(_id) => this.props.deleteProduct(_id)}
                                getProduct={(_id) => this.props.getProduct(_id)}
                                updateProduct={(product) => this.props.updateProduct(product)}
                                editProduct={this.props.editProduct}

                                productTypes={this.props.productTypes} />
                            : path.includes('/producttypeslist') ?
                                <ProductTypesList
                                    productTypes={this.props.productTypes}
                                    addProductType={(productType) => this.props.addProductType(productType)}
                                    deleteProductType={(_id) => this.props.deleteProductType(_id)}
                                    getProductType={(_id) => this.props.getProductType(_id)}
                                    updateProductType={(type)=>this.props.updateProductType(type)}
                                    editProductType={this.props.editProductType}

                                /> : path.includes(pageURL) ? <ProductDetails product={productPageURL} /> :path.includes('/about') ? <About /> : <Home />
                }
            </div>
        )
    }

}

const mapStateToProps = (centralState) => {
    return {
        editProductType: centralState.editProductType,
        productTypes: centralState.productTypes,
        editProduct: centralState.editProduct,
        products: centralState.products,

    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        fetchProducts: () => { dispatch(fetchProducts()) },
        addProduct: (product) => { dispatch(addProduct(product)) },
        deleteProduct: (_id) => { dispatch(deleteProduct(_id)) },
        getProduct: (_id) => { dispatch(getProduct(_id)) },
        updateProduct: (product) => { dispatch(updateProduct(product)) },

        fetchProductTypes: () => { dispatch(fetchProductTypes()) },
        addProductType: (productType) => { dispatch(addProductType(productType)) },
        deleteProductType: (_id) => { dispatch(deleteProductType(_id)) },
        getProductType: (_id) => { dispatch(getProductType(_id)) },
        updateProductType: (type) => {dispatch(updateProductType(type))}
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(App)