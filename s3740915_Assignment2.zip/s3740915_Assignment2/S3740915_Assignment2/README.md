# redux-template

This puts up all the boiler plate used in a new Redux project. 
It contains 3 sample components: Counter, Caculator, and Student
Students learn:
- Structure of a Redux project
- How to use constructor
- How to use event handler
- How to use state to control values of all input controls
- How to use map to display a list of students
- How to add new element to a list
