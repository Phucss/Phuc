import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import {combineReducers, createStore, applyMiddleware} from 'redux';
import { composeWithDevTools } from 'redux-devtools-extension';
import {Provider} from 'react-redux';
import thunk from 'redux-thunk';
import productTypes from './src/reducers/productTypeReducers.jsx';
import products from './src/reducers/productsReducer.jsx';
import editProduct from './src/reducers/editProduct.jsx';
import editProductType from './src/reducers/editProductType.jsx';

var centralState = combineReducers({
    editProductType:editProductType,
    productTypes : productTypes,
    editProduct: editProduct,
    products : products
})

var store = createStore(centralState, composeWithDevTools(applyMiddleware(thunk)))

ReactDOM.render(
<Provider store={store}>    
    <App />
</Provider>,document.getElementById('app'))