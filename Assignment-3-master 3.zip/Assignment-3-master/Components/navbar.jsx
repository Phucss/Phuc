import React,{ Component } from 'react'
import './navbar.css'
export default class Navbar extends React.Component {
    render() {
      return (
        <section className="hero has-background-black">

        <div className="navbar">
          <div className="column center is-2">
            <img src="Logo VCS.png" sizes="auto"/>
          </div>
            <div className="column center is-4">
              <div className="search-box">
                <input className='search-text'type='text' placeholder='Type to Search'/>
                
                <a className='search-btn' href='#'>
                <i className="fas fa-search"></i>
                </a>
              </div>
            </div>
            <div className="column center">
              <a className="a nav-link" href="/app"> Home</a>
          </div>
            <div className="column center">
              <a className="a nav-link" href="/adsPage">Ads  </a>
          </div>
            <div className="column center">
              <a className="a nav-link" href="/projectPage">Projects </a>
          </div>

          </div>
  
  
        </section>
      )
    }
}