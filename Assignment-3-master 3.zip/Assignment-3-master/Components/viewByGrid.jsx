import React, { Component } from 'react'



export default class ViewByGrid extends Component {
    constructor(props) {
        super(props);
        this.state = {
            formVisibility: false,
            currentAds: props.ads,
        }
    }

    componentWillReceiveProps(nextProps) {
        this.setState({ currentAds: nextProps.ads })
    }

   

    displayForm() {
        this.setState({ formVisibility: !this.state.formVisibility })
    }

    closeForm() {
        this.setState({ formVisibility: false })
    }

    handleEdit(_id) {
        this.displayForm()
        this.props.getAds(_id)
    }

    onFind(e) {
        var target = e.target
        var name = target.name
        var value = target.value
        this.setState({
            [name]: value
        })
        var loweredKeyWord = this.state.keyWord.toLowerCase()
        if (this.state.keyWord === '') {
            this.setState({ currentAds: this.props.ads })
        }
        this.setState({
            currentAds: this.props.ads.filter(ads =>
                ads.name.toLowerCase().indexOf(loweredKeyWord) !== -1

            )
        })
    }

    clearKey() {
        this.setState({
            currentProducts: this.props.ads,
            keyWord: ''
        })
    }

    render() {
        var { formVisibility } = this.state
       
        return (
            <div>

                <br /><br /><br />
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-sm-3">
                        </div>
                        <div className="col-sm-3" align="center">
                        <div className='card filter-card'>
                            <div className='card-header bg-dark text-white'>
                                <h4 className='card-title'>Filter</h4>
                            </div>
                            <div className='card-body'>
                                                                
                                <div className='card-header'>
                                    <h5 className='card-title'>
                                        <a href='#byPrice'>
                                            <i className></i> Price
							            </a>
                                    </h5>
                                </div>
                                <div id='byPrice' className='card-collapse collapse in' >
                                    <ul className='list-group'>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('ALL')}>
                                                All
                                            </button>
                                        </li>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('LO_TO_HI')}>
                                                Low To High
                                            </button>
                                        </li>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('HI_TO_LO')}>
                                                High To Low
                                            </button>
                                        </li>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('0_500')}>
                                                $0 - $500
                                            </button>
                                        </li>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('500_2000')}>
                                                $500 - $2000
                                            </button>
                                        </li>
                                        
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('ABOVE_2000')}>
                                                Above $2000
                                            </button>
                                        </li>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('ABOVE_5000')}>
                                                Above $5000
                                            </button>
                                        </li>
                                        <li className='list-group-item'>
                                            <button className='btn btn-primary w-100' onClick={() => this.handleFilterByPrice('ABOVE_10000')}>
                                                Above $10000
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                           
                        </div>
                        <div className="col-sm-3" align="center">
                        <div className="form-group">
                                <label htmlFor=""><h3>Search:</h3></label>

                                
                                <input style={{ width: '300px' }} type="text" className="form-control" name="keyWord" value={this.state.keyWord} onChange={this.onFind.bind(this)} />
                                <br/>
                                <button className="btn btn-standard" onClick={this.displayForm.bind(this)} >Add Product</button>
                              
                            </div>
                        </div>
                        <div className="col-sm-3">
                        </div>
                    </div>
                </div>
                <br />

                <div className="contaier-fluid">
                    <div className="row">
                        <div className="col-sm-3"></div>
                        <div className="col-sm-6">
                            {/* {productForm} */}
                        </div>
                        <div className="col-sm-3"></div>
                    </div>
                </div>

                <br />

                <div className="row">
   

                    <div className="col-sm-12">
                        <div className="row">
                            {this.state.currentAds.map((ads, index) =>
                                <div className="col-sm-4" key={index} align="center" id="card">
                                    <div className='card border-dark card-cascade h-100 '>

                                        

                                        <div className='card-body'>
                                            <h4 className='h5 card-title'>{ads.title}</h4>
                                            <hr />
                                            <p className='p card-text'><b>Price:</b>${ads.price}</p>
                                            <p className='p card-text'><b>Brand:</b> {ads.project}</p>
                                            
                                        </div>

                                        <div className="card-body">
                                            <button className="btn btn-standard"><a href={`${ads._id}`}>View</a></button> &nbsp;&nbsp;
                                            <button className="btn btn-danger" onClick={() => this.props.deleteAds(ads._id)}>Delete</button>&nbsp;&nbsp;
                                            <button className="btn btn-standard" onClick={() => this.handleEdit(ads._id)}>Edit</button>&nbsp;&nbsp;
                                        </div>

                                        

                                    </div>
                                    <br />
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </div>

        )
    }
}
