import React from 'react'


export default class ProjectPage extends React.Component{
    render(){
        return(
            <div></div>
        )
    }
}