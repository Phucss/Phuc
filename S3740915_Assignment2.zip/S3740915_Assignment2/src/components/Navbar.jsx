import React, { Component } from 'react'
import './navbar.css'
const url=`https://fathomless-escarpment-67497.herokuapp.com/ads/`;


export default class Navbar extends Component {
	constructor(){
		super()
		this.state={
		  ads: [],
		  search: ''
		}
	}
	
	fetchAds(){
		fetch(url)
		.then(res=>res.json())
		.then(json=>this.setState({ads: json}))
	
	}
	componentDidMount(){
		this.fetchAds()
	}
	onChange(event){
		this.setState({search:event.target.value})
		
	}
	
	render() {
		let filterAds = this.state.ads.filter(
			(ads)=>{
			  if(this.state.search.length === 0){
					return null
			  }
			  else{
					return ads.title.toLowerCase().indexOf(this.state.search.toLowerCase()) !== -1;
			  }
			}
		   )
		return (
			<div className="row has-background-black" align="center" >
				<div className="column center is-2">
					<img src="Logo VCS.png" sizes="auto"/>
				</div>

				<div className="column center is-4">
					<div className="search-box">
						<input className='search-text'
							type='text' 
							placeholder='Type to Search' 
							value = {this.state.search}
							onChange = {this.onChange.bind(this)}
						/>
					
							
							<i className="fas fa-search"></i>
						
					</div>
					<div className="dropdown-content">
						<ul className= 'ulAdsList'>
							{filterAds.map(a=>
							<a href={`${a._id}`}>
								<li className="w-120 adsList" >{a.title}</li>
							
							</a>
							)}
						</ul>
					</div>
				</div>

				<div className="column center">
					<a className="a nav-link" href="/home"><h3> Home</h3>  </a>
				</div>

				
				<div className="column center">
					<a className="a nav-link" href="/productslist"><h3> Ads</h3> </a>
				</div>
				<div className="column center">
					<a className="a nav-link" href="/producttypeslist"><h3> Project</h3> </a>
				</div>

			</div>
		)
	}
}