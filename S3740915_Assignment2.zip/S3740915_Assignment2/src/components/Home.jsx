import React, { Component } from 'react'
import Footer from './Footer.jsx'


import Navbar from './Navbar.jsx';


export default class Home extends Component {
	render() {
		return (
			<div>
				<Navbar></Navbar>
				<br/><br/><br/><br/>

				<div className='welcome' align='center'>
					<h2>Welcome to RNG Store</h2>
				</div>
				
				<br/><br/><br/><br/>
				<br/><br/><br/><br/>
				<br/><br/><br/><br/>
				<Footer/>
				
			</div>

		)
	}
}
