import React, { Component } from 'react'
import NavBar from '../Navbar.jsx'

export default class ProductDetails extends Component {
    render() {
        return (
            
            <div>
                <NavBar/>
                <div className="container">
                    <div className="row">
                        
                        <div className="col-sm-12" align="center">
                            <h1 className="h1" >Ads Details</h1>
                        </div>
                        
                    </div>
                </div>
                <br /><br />
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12" align="center">
                            <h3 className="h3">{this.props.product.title}</h3>
                           
                        </div>
                 
                    </div>
                </div>
                <br /><br />
                <div className="container">
                    <div className="row">
                        <div className="col-sm-12">
                            
                            <br /><br />
                            <h4 className="h4">Price: {this.props.product.price}</h4>
                            <h4 className="h4">Address: {this.props.product.address}</h4>
                            <h4 className="h4">Contact Info</h4>
                            <h5 className="p">Owner :{this.props.product.contact_info.name}</h5>
                            <h5 className="p">Phone :{this.props.product.contact_info.phone}</h5>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
