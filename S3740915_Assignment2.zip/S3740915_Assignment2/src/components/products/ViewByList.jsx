import React, { Component } from 'react'
import ProductForm from './ProductForm.jsx'

import Navbar from '../Navbar.jsx';
var styles = {
    h1: {
        textalign: 'center'
    },
    img: {
        height: '300px',
        width: '300px',
    },
    td: {
        width: 'auto'
    },
    btn: {

        fontSize: '15px',

        width: '100px'
    },
    p: {
        color: 'white'
    },

}

export default class ViewByList extends Component {
    constructor(props) {
        super(props);
        this.state = {
            formVisibility: false,
            currentProducts: props.products,
            keyWord: ''
        }
    }

    componentWillReceiveProps(nextProps) {
        this.setState({ currentProducts: nextProps.products })
    }




    handleFilterByPrice(filter) {
    if (filter === '0_500') {
            let firstCase = this.props.products.filter((product) => product.price <= 500)
            this.setState({ currentProducts: firstCase })
        }
        else if (filter === '500_2000') {
            let secondCase = this.props.products.filter((product) => product.price >= 500 && product.price <= 2000)
            this.setState({ currentProducts: secondCase })
        }

        else if (filter === 'ABOVE_2000') {
            let fourthCase = this.props.products.filter((product) => product.price >= 2000)
            this.setState({ currentProducts: fourthCase })
        }
        else if (filter === 'ABOVE_5000') {
            let fifthCase = this.props.products.filter((product) => product.price >= 5000)
            this.setState({ currentProducts: fifthCase })
        }
        else if (filter === 'ABOVE_10000') {
            let sixthCase = this.props.products.filter((product) => product.price >= 10000)
            this.setState({ currentProducts: sixthCase })
        }
        else if (filter === 'ALL') {
            this.setState({ currentProducts: this.props.products })
        }
    }

    onFind(e) {
        var target = e.target
        var name = target.name
        var value = target.value
        this.setState({
            [name]: value
        })
        var loweredKeyWord = this.state.keyWord.toLowerCase()
        if (this.state.keyWord === '') {
            this.setState({ currentProducts: this.props.products })
        }
        this.setState({
            currentProducts: this.props.products.filter(product =>
                product.name.toLowerCase().indexOf(loweredKeyWord) !== -1

            )
        })
    }

    clearKey() {
        this.setState({
            currentProducts: this.props.products,
            keyWord: ''
        })
    }


    displayForm() {
        this.setState({ formVisibility: !this.state.formVisibility })
    }

    closeForm() {
        this.setState({ formVisibility: false })
        this.props.onViewList()
    }

    handleEdit(_id) {
        this.displayForm()
        this.props.getProduct(_id)
    }



    render() {
        var { formVisibility } = this.state
        var productForm = formVisibility ? <ProductForm
            addProduct={(product) => this.props.addProduct(product)}
            closeForm={this.closeForm.bind(this)}
            formVisibility={this.state.formVisibility}
            editProduct={this.props.editProduct}
            updateProduct={(product) => this.props.updateProduct(product)}

            productTypes={this.props.productTypes} /> : null

        return (
            <div>

                <br /><br /><br />
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-sm-3">
                            <div className='card filter-card'>
                                <div className='card-header bg-light'>
                                    <h4 className='card-title'>Filter</h4>
                                </div>
                                <div className='card-body'>

                                    <div id='byCategory' className='card-collapse collapse in' >
                                        <ul className='list-group'>
                                            <li className="list-group-item">
                                                <button style={styles.btn1} className='btn btn-standard w-100' onClick={() => this.handleFilterByCategory('all')} >All</button>
                                            </li>
                                            {this.props.productTypes.map((type, index) =>
                                                <li key={index} className='list-group-item'>
                                                    <button style={styles.btn1} className='btn btn-standard w-100' onClick={() => this.handleFilterByCategory(type.name)} >
                                                        {type.name}
                                                    </button>
                                                </li>
                                            )}
                                        </ul>
                                    </div>
                                    <div className='card-header'>
                                        <h5 className='card-title'>
                                            <a data-toggle='collapse' href='#byPrice'>
                                                <i className='indicator fa fa-caret-down'></i> Price
							            </a>
                                        </h5>
                                    </div>
                                    <div id='byPrice' className='card-collapse collapse in' >
                                        <ul className='list-group'>
                                            <li className='list-group-item'>
                                                <button style={styles.btn1} className='btn btn-standard w-100' onClick={() => this.handleFilterByPrice('ALL')}>
                                                    All
                                            </button>
                                            </li>
                                            
                                            <li className='list-group-item'>
                                                <button style={styles.btn1} className='btn btn-standard w-100' onClick={() => this.handleFilterByPrice('0_500')}>
                                                    $0 - $500
                                            </button>
                                            </li>
                                            <li className='list-group-item'>
                                                <button style={styles.btn1} className='btn btn-standard w-100' onClick={() => this.handleFilterByPrice('500_2000')}>
                                                    $500 - $2000
                                            </button>
                                            </li>

                                            <li className='list-group-item'>
                                                <button style={styles.btn1} className='btn btn-standard w-100' onClick={() => this.handleFilterByPrice('ABOVE_2000')}>
                                                    More than $2000
                                            </button>
                                            </li>
                                            <li className='list-group-item'>
                                                <button style={styles.btn1} className='btn btn-standard w-100' onClick={() => this.handleFilterByPrice('ABOVE_5000')}>
                                                    More than $5000
                                            </button>
                                            </li>
                                            <li className='list-group-item'>
                                                <button style={styles.btn1} className='btn btn-standard w-100' onClick={() => this.handleFilterByPrice('ABOVE_10000')}>
                                                    $10000 +
                                            </button>
                                            </li>

                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-sm-3" style={{ padding: '25px' }} align="center">
                            
                        </div>
                        <div className="col-sm-3" align="center">
                            <div className="form-group">
                                <label htmlFor=""><h3>Search:</h3></label>

                                
                                <input style={{ width: '300px' }} type="text" className="form-control" name="keyWord" value={this.state.keyWord} onChange={this.onFind.bind(this)} />
                                <br/><br/>
                                <button className="btn btn-standard" onClick={this.displayForm.bind(this)} >Add Product</button>
                              
                            </div>
                        </div>
                        <div className="col-sm-3">
                        </div>
                    </div>
                </div>
                <br />


                <div className="contaier-fluid">
                    <div className="row">
                        <div className="col-sm-12">
                            {productForm}
                        </div>
                    </div>
                </div>

                <br />
                <br />
                <br />

                <div className="container-fluid">
                    <div className="row">
                        <div className="col-sm-2">

                        </div>

                        <div className="table table-bordered col-md-12">
                            <table className="table">
                                <thead className="thead-light text-center">
                                    <tr>
                                        <th>No.</th>
                                        <th>Product Name</th>
                                        <th>Price</th>
                                        <th>Description</th>
                                        <th>Brand</th>
                                        <th>Producer</th>
                                        <th>Image</th>
                                        <th>Product Type</th>
                                        <th>More Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {this.state.currentProducts.map((product, index) =>
                                        <tr className="" key={index} >
                                            <td style={styles.td} ><p className="p">{index + 1}</p></td>
                                            <td style={styles.td}><p className="p">{product.name}</p></td>
                                            <td style={styles.td}><p className="p">${product.price}</p></td>
                                            <td style={styles.td}><p className="p">{product.description}</p></td>
                                            <td style={styles.td}><p className="p">{product.brand}</p></td>
                                            <td style={styles.td}><p className="p">{product.producer}</p></td>
                                            <td align="center"><img src={product.imageUrl} alt="" style={styles.img} /></td>
                                            <td style={styles.td}><p className="p">{product.productType}</p></td>
                                            <td style={styles.td}>
                                                <div>
                                                    <p style={styles.p} ><a style={styles.btn} className='btn btn-success btn-circle' role='button'
                                                        href={`${product._id}`}>View
                                                </a></p>

                                                    <p style={styles.p}><a style={styles.btn} className='btn btn-danger ' role='button' onClick={() => this.props.deleteProduct(product._id)} >Delete</a></p>

                                                    <p style={styles.p}><a style={styles.btn} className='btn btn-success ' role='button' onClick={() => this.handleEdit(product._id)}>Edit</a></p>
                                                </div>
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>


            </div>
        )
    }
}
