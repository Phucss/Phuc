import React, { Component } from 'react'
import ViewByList from '../productTypes/ViewByList.jsx'
import Navbar from '../Navbar.jsx';


export default class ProductTypesList extends Component {

	render() {
		return (
			<div>
				<Navbar></Navbar>
				<div className="container">
				<br/>
					<div className="row">
					
						<div className="col-sm-12">
							<h1 className="h1" align="center">Product Types</h1>
						</div>
						
					</div>
				</div>
				<br/><br/>
				<ViewByList
					onViewList={() => this.onViewList.bind(this)}
					productTypes={this.props.productTypes}
					addProductType={(productType) => this.props.addProductType(productType)}
					deleteProductType={(_id) => this.props.deleteProductType(_id)}
					getProductType={(_id) => this.props.getProductType(_id)}
					updateProductType={(type) => this.props.updateProductType(type)}
					editProductType={this.props.editProductType}

					productTypes={this.props.productTypes} />
					
			</div>
		)
	}
}
