import React, { Component } from 'react'

export default class ProductTypeForm extends Component {
	constructor(props) {
		super(props);
		this.state = {
			id: '',
			name: ''
		}
	}

	componentWillReceiveProps(props) {
		this.setState(props.editProductType)
		
	}

	handleChange(e) {
		let change = {}
		change[e.target.name] = e.target.value
		this.setState(change)
	}

	handleSubmit() {
		if (this.state._id === undefined || this.state._id === null) {
			this.props.addProductType(this.state)
			this.clearForm()
			this.props.closeForm()
		}
		else {
			this.props.updateProductType(this.state)
			this.clearForm()
			this.props.closeForm()
		}
	}

	clearForm() {
		this.setState({
			id: '',
			name: ''
		})
	}

	render() {
		console.log(this.state)
		return (
			<div>
				<div className="container-fluid">
					<div className="row">
						<div className="col-sm-12">
							<div className="card">
								<div className="card-header text-center bg-standard text-black" >
									{!this.state._id ? 'Product Type Information' : 'Edit Form'}
									
								</div>
								<div className="card-body">
									<form>
										<div className="form-row">
											<div className="col">
												<label >ID</label>
												<input type='text' name='id' className='form-control' placeholder='ProductType ID'
													value={this.state.id} onChange={this.handleChange.bind(this)} autoFocus />
											</div>

											<div className='col'>
												<label>Product Type Name</label>
												<input type='text' name='name' className='form-control' placeholder='ProductType Name'
													value={this.state.name} onChange={this.handleChange.bind(this)} />
											</div>
											<br />
											
										
										</div>
										<br/>
										<button className='btn btn-standard inline mr-1'
												onClick={this.handleSubmit.bind(this)}
											>
												{!this.state._id ? 'Add' : 'Save'}
											</button>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		)
	}
}
