const products = (state = [], action) => {
    switch (action.type) {
        case 'FETCH_PRODUCTS_SUCCESS':
            state = action.payload;
            console.log('Fetched Successfully')
            return state;
        case 'ADD_PRODUCT':
            console.log('Added Successfully')
            return [...state, action.payload];
        case 'DELETE_PRODUCT':
            console.log('Delete Called')
            return state.filter((res) => res._id !== action.payload)
        default:
            return state;
    }
}

export default products;