export function fetchProductTypes() {
    return (dispatch) => {
        fetch(`http://rmit.chickenkiller.com:8080/productTypes`)
        .then((res) => {return res.json()})
        .then((data) => {
            dispatch({
                type : 'FETCH_TYPES_SUCCESS',
                payload : data
            })
        })
    }
}

export function addProductType(productType){
    return (dispatch) => {
        fetch(`http://rmit.chickenkiller.com:8080/productTypes`, {
           headers: {
               'Accept' : 'application/json, text/plain, */*',
               'Content-Type':'application/json'
           },
           method: 'POST',
           body: JSON.stringify(productType)
        })
        .then((res) => {return res.json()})
        .then((data) => {
            dispatch({
                type: 'ADD_TYPE',
                payload: data
            })
        })
    }
}

export function deleteProductType(_id) {
    return (dispatch) => {
        if (confirm('Do you want to delete?')) {
        fetch(`http://rmit.chickenkiller.com:8080/productTypes/${_id}`,{
            method: 'DELETE'
        })
        .then((res)=> {return res.json()})
        .then(dispatch({
            type: 'DELETE_TYPE',
            payload: _id
        }))
    }
}
}

export function updateProductType(type){
    return (dispatch) => {
        console.log(type);
        fetch(`http://rmit.chickenkiller.com:8080/productTypes/`,{
            headers: {
                'Accept': 'application/json, text/plain, */*',
                'Content-Type': 'application/json' 
            },
            method: 'PUT',
            body: JSON.stringify(type)
        })
        .then((res)=> {return res.json()})
        .then((data)=>dispatch(fetchProductTypes()))
    }
}

export function getProductType(_id){
    return (dispatch) => {
        fetch(`http://rmit.chickenkiller.com:8080/productTypes/${_id}`, {
            method: 'GET',
        })
        .then((res)=>{return res.json()})
        .then((data) => {
            dispatch({
                type: 'EDIT_TYPE',
                payload: data
            })
        })
    }
}

export function resetProductType(){
    return {
        type: 'RESET_CATEGORY'
    }
}