import React, { Component } from 'react'
import ProductTypeForm from './ProductTypeForm.jsx'


var styles = {
	h1: {
		textAlign: 'center'
	},
	img: {
		height: '300px',
		width: '300px',
	},
	td: {
		width: 'auto'
	},
	btn: {
		
		fontSize: '15px',
		
		width: '100px'
	},
	p: {
		color: 'white'
	}
}

export default class ViewByList extends Component {
	constructor(props) {
		super(props);
		this.state = {
			formVisibility: false,
			currentProductTypes: props.productTypes
		}
	}

	componentWillReceiveProps(nextProps) {
		this.setState({ currentProductTypes: nextProps.productTypes })

	}

	displayForm() {
		this.setState({ formVisibility: !this.state.formVisibility })
	}

	closeForm() {
		this.setState({ formVisibility: false })
	}

	handleEdit(_id) {
		this.displayForm()
		this.props.getProductType(_id)
	}

	render() {
		var { formVisibility } = this.state
		var productTypeForm = formVisibility ? <ProductTypeForm
			addProductType={(productType) => this.props.addProductType(productType)}
			deleteProductType={(_id) => this.props.deleteProductType(_id)}
			getProductType={(_id) => this.props.getProductType(_id)}
			updateProductType={(type) => this.props.updateProductType(type)}
			editProductType={this.props.editProductType}
			closeForm={this.closeForm.bind(this)}
		/> : null

		return (
			<div>

				<div className="container-fluid">
					<div className="row">
						<div className="col-sm-12" align="center">
							<button className="btn btn-standard" onClick={this.displayForm.bind(this)} >Add Product Type</button>
							<br />
							<br />
							<br />
							{productTypeForm}
						</div>
					</div>
				</div>

				<br /><br />
				<div className="container-fluid">
					<div className="row">
						<div className="table table-responsive table-bordered col-sm-12">
							<table className="table">
								<thead className="thead-light text-center" >
									<tr>
										<th>No.</th>
										<th>ID</th>
										<th>Name of Product Type</th>
										<th>More Details</th>
									</tr>
								</thead>
								<tbody>
									{this.state.currentProductTypes.map((type, index) =>
										<tr className="" key={index} >
											<td>{index + 1}</td>
											<td>{type.id}</td>
											<td>{type.name}</td>
											<td>
												<div>
												<p style={styles.p}><a style={styles.btn} className='btn btn-danger ' role='button' onClick={() => this.props.deleteProductType(type._id)}>Delete</a></p>
												<p style={styles.p}><a style={styles.btn} className='btn btn-success ' role='button' onClick={() => this.handleEdit(type._id)}>Edit</a></p>
												
												

                                                   
												</div>

											</td>
										</tr>
									)}
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		)
	}
}
