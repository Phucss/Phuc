import React, { Component } from 'react'
import ViewByList from '../products/ViewByList.jsx'
import ViewByGrid from '../products/ViewByGrid.jsx'
import './productList.css'
import Navbar from '../Navbar.jsx';
import Footer from '../Footer.jsx';




export default class ProductsList extends Component {
	constructor(props) {
		super(props)
		this.state = {
			viewByList: false,
			viewByGrid: false
		}
	}
	onViewList() {
		this.setState({
			viewByList: !this.state.viewByList,
			viewByGrid: false
		})
	}

	onViewGrid() {
		this.setState({
			viewByGrid: !this.state.viewByGrid,
			viewByList: false
		})
	}

	render() {
		return (
			<div>
				<Navbar></Navbar>
				<div align="center">
				<br/>
					<h2>
					Here is our Ads 
					</h2>
					<br/>
					<h2>
					
					</h2>
				</div>
			
				<div className="container">
					<div className="row">
						<div className="col-sm-12" align="center">
							
							
						</div>
					</div>
				</div>
				

				<ViewByGrid
					onViewGrid={this.onViewGrid}
					products={this.props.products}
					addProduct={(product) => this.props.addProduct(product)}
					deleteProduct={(_id) => this.props.deleteProduct(_id)}
					getProduct={(_id) => this.props.getProduct(_id)}
					editProduct={this.props.editProduct}
					updateProduct={(product) => this.props.updateProduct(product)}

					productTypes={this.props.productTypes} />
				<br />
				<Footer/>
			</div>
		)
	}
}
