const productTypes = (state = [], action) => {
    switch (action.type) {
        case 'FETCH_TYPES_SUCCESS':
            state = action.payload;
            return state;
        case 'ADD_TYPE':
            return [...state, action.payload];
        case 'DELETE_TYPE':
            return state.filter((res) => res._id !== action.payload)
        default:
            return state;
    }
}

export default productTypes;