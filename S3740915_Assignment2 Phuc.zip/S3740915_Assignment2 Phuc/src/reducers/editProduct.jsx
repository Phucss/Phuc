const editProduct = (state = {}, action) => {
    switch(action.type){
        case 'EDIT_PRODUCT':
            console.log('Edit Called')
            return action.payload;
        default: 
            return state;
    }
};

export default editProduct;
